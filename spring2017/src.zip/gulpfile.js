var gulp = require('gulp');
var sourcemaps = require('gulp-sourcemaps');
var source = require('vinyl-source-stream');
var buffer = require('vinyl-buffer');
var browserify = require('browserify');
var watchify = require('watchify');
var gulpwatch = require('gulp-watch');
var babel = require('babelify');
var less = require('gulp-less');
var moment = require('moment');

function compile(watch) {
  var bundler = watchify(browserify('./src/js/index.js', { debug: true }).transform(babel));

  function rebundle() {
    gulp.src("./src/webroot/**/*.html")
      .pipe(gulp.dest("./build"));

    gulp.src("./src/webroot/**/*.less")
      .pipe(less({}))
      .pipe(gulp.dest('./build'));

    gulp.src("./src/webroot/assets/**/*")
      .pipe(gulp.dest("./build/assets"));

    bundler.bundle()
      .on('error', function(err) { console.error(err); this.emit('end'); })
      .pipe(source('build.js'))
      .pipe(buffer())
      .pipe(sourcemaps.init({ loadMaps: true }))
      .pipe(sourcemaps.write('./'))
      .pipe(gulp.dest('./build'));
  }

  if (watch) {
    gulpwatch('./src/**/*', function() {
      console.log("-> bundling @ " + moment().format("HH:mm:ss"));
      rebundle();
    });
  }

  rebundle();
}

function watch() {
  return compile(true);
};

gulp.task('build', function() { return compile(); });
gulp.task('watch', function() { return watch(); });

gulp.task('default', ['watch']);
