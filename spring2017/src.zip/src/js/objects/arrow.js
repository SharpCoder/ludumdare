var Drawable = require('../drawable');

class Arrow extends Drawable {

  constructor(obj) {
    super(_.defaults({}, obj, {
      image: "arrow",
      time: 0
    }));
  }

  update(cw, ch) {
    this.vx = Math.sin(0.25 * this.time);
    this.vy = Math.sin(0.25 * this.time);
    this.time++;
    super.update(cw,ch);
  }


}

module.exports = Arrow;
