var _ = require('underscore');
var Drawable = require('../drawable');

class ForestPlanet extends Drawable {

  constructor(obj) {
    super(_.defaults({}, obj, {
      x: 250,
      y: 250,
      mass: 150,
      rotationSpeed: .75 + (1 * Math.random()),
      rotatePlayer: true
    }));

    this.arbols = [];
    for (var i = 0; i < 15 + Math.random() * 40; i++) {
      let size = 35 + (Math.random() * 50);
      let angle = Math.round(360 * Math.random());
      if (angle > 235 && angle < 300) {
        angle += 120;
      }

      let theta = angle * Math.PI / 180;
      let r = (this.width) / 2;
      let ox = r * Math.cos(theta);
      let oy = r * Math.sin(theta);

      var tree = new Drawable({
        image: "tree",
        ox: ox,
        oy: oy,
        width: size,
        height: size
      });

      this.arbols.push(tree);
      this.addAsset(tree)
    }
  }

  setPlayer(player) {
    let theta = 90 * Math.PI / 180;//Math.round(360 * Math.random()) * Math.PI / 180;
    let r = (this.width) / 2;
    let ox = r * Math.cos(theta);
    let oy = r * Math.sin(theta);

    let factor = 3;
    player.width = player.width / factor;
    player.height = player.height / factor;
    player.ox = ox;
    player.oy = oy - this.height - 30;
    this.player = player;
    this.addAsset(player);
  }

  update(cw, ch) {
    this.rotation += this.rotationSpeed;
    if (this.mainGravitySource) {
      this.y = ch/2;
      this.x = cw/2;
    }

    var ctx = this;
    this.arbols.map(function(tree){
      tree.sr = Math.atan2(tree.oy, tree.ox) * 180/Math.PI;
      tree.sr += 90;
      tree.rax = ctx.x;
      tree.ray = ctx.y;
      tree.rotation = ctx.rotation;
    });

    if (exists(this.player) && this.rotatePlayer) {
      this.player.rax = ctx.x;
      this.player.ray = ctx.y;
      this.player.rotation = ctx.rotation;
    }

    super.update(cw, ch);
  }

  stopRotatingPlayer() {
    this.rotatePlayer = false;
  }


}

module.exports = ForestPlanet;
