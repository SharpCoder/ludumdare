var _ = require('underscore');
var Drawable = require('../drawable');

class Nice extends Drawable {

  constructor(obj) {
    super(_.defaults({}, obj, {
      delay: 3000,
      power: 0,
      vy: -5
    }));

    this.then = Date.now();
  }

  draw(ctx) {
    if (this.visible == false) {
      return;
    }

    ctx.font = "48px Neucha";
    ctx.fillStyle = "#FFF";
    ctx.fillText(this.text, this.x, this.y);
  }

  update(cw,ch) {
    super.update(cw, ch);
    let now = Date.now();
    let elapsed = now - this.then;
    if (elapsed >= this.delay) {
      this.visible = false;
      if (exists(this.success)) {
        this.success();
      }
    }
  }

}

module.exports = Nice;
