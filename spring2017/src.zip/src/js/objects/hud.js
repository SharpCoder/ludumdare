var _ = require('underscore');
var Drawable = require('../drawable');

class Hud extends Drawable {

  constructor(obj) {
    super(_.defaults({}, obj, {
      fuel: window.fuel,
      power: 0
    }));
  }

  setPower(power) {
    this.power = power;
  }

  setFuel(fuel) {
    this.fuel = fuel;
  }

  draw(ctx) {
    if (this.visible == false) {
      return;
    }

    ctx.font = "24px Neucha";
    ctx.fillStyle = "#87cb41";
    ctx.fillText("Level: " + window.level, 20, 150 + 200);
    ctx.fillStyle = "#FFF";
    ctx.fillText("Fuel: " + window.fuel, 20, 150 + 50);
    ctx.fillText("Power: " + this.power, 20, 150 + 100);
    ctx.fillText("Score: " + window.score, 20, 150 + 150);
  }

}

module.exports = Hud;
