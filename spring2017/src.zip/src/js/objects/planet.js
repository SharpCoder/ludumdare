var _ = require('underscore');
var Drawable = require('../drawable');

class Planet extends Drawable {

  constructor(obj) {
    super(_.defaults({}, obj, {
      x: 250,
      y: 250,
      mass: 200
    }));
  }

  update(cw, ch) {
    this.rotation += 1;
    super.update();
  }


}

module.exports = Planet;
