var _ = require('underscore');
var Drawable = require('../drawable');

class Explosion extends Drawable {

  constructor(obj) {
    super(_.defaults({}, obj, {
      delay: 100,
      loop: false
    }));

    this.then = Date.now();
    this.index = 0;
    this.maxIndex = 4;
    for (var index = 1; index < 6; index++ ) {
      let args = _.defaults({}, obj, {
        image: "explosion_" + index
      });

      this["explosion" + index] = new Drawable(args);
    }
  }

  draw(ctx, cw, ch) {
    if (this.visible) {
      let obj = this["explosion" + (this.index + 1)];
      obj.draw(ctx, cw, ch);
    }
  }

  update(cw, ch) {
    super.update(cw, ch);
    let now = Date.now();
    let elapsed = (now - this.then);
    if (elapsed >= this.delay) {
      this.index = this.index + 1;

      if (this.loop == true) {
        this.index = this.index % this.maxIndex;
      } else if (this.index > this.maxIndex) {
        this.visible = false;
        if (exists(this.complete)) {
          this.complete();
        }
      }
      this.then = now;
    }
  }


}

module.exports = Explosion;
