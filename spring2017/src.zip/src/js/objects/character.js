var Drawable = require('../drawable');

class Character extends Drawable {

  constructor() {
    super({
      image: "rocket"
    });
  }


}

module.exports = Character;
