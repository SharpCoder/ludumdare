var _ = require("underscore");

class Drawable {
  constructor(options) {
    this.assets = [];
    let attrs = _.defaults({}, options, {
      z: 0,
      x: 0,
      y: 0,
      ox: 0, // offsetX
      oy: 0, // offsetY
      vx: 0,
      vy: 0,
      gv: 1.0,
      gravityDelay: 5,
      mainGravitySource: false, // Used only for rotation
      rumbling: false,
      visible: true,
      rotation: 0,
      rax: null, // rotation anchor X
      ray: null, // rotation anxhor Y
      sr: 0, // static rotation
      type: null,
      gravity: false
    });

    if (exists(attrs.image)) {
      let imageObject = Assets.get(attrs.image);
      attrs.image = imageObject;

      if (!exists(attrs.width))
        attrs.width = imageObject.width;

      if (!exists(attrs.height))
        attrs.height = imageObject.height;
    }

    for(var prop in attrs) {
      this[prop] = attrs[prop];
    }

    this.then = Date.now();
  }

  getAssets() {
    let results = [];
    results.push(this);
    this.assets.map(function(asset) {
      results = results.concat(asset.getAssets());
    });
    return results;
  }

  addAsset(drawable, zindex) {
    drawable.z = zindex || 0;
    this.assets.push(drawable);
  }

  draw(ctx, cw, ch) {
    if (!this.visible) { return; }

    if (exists(this.image)) {
      ctx.save();

      if (this.rumbling) {
        let x = Math.random() - Math.random();
        let y = Math.random() - Math.random();
        let range = (this.rumbleRange || 15) * .015;
        range = Math.min(range, 25);
        ctx.translate(x * range, y * range);
      }

      if (this.type == "scaled") {
        let adjustH = this.height * (this.height / ch);
        ctx.drawImage(this.image, this.x, this.y, this.width, this.height,this.x, this.y, cw, ch);
      } else {


        if (this.rax || this.ray) {
          ctx.translate(this.rax, this.ray);
          ctx.rotate(this.rotation * Math.PI / 180);
          ctx.translate(this.ox, this.oy);
          ctx.rotate(this.sr * Math.PI / 180);
        } else {
          ctx.translate(this.x + this.ox, this.y + this.oy);
          ctx.rotate(this.rotation * Math.PI / 180);
        }

        ctx.drawImage(this.image, -(this.width/2), -(this.height/2), this.width, this.height);
      }
      ctx.restore();
    }

    _.map(this.assets, function(asset){ asset.draw(ctx, cw, ch); });
  }

  setVisible(visible) {
    this.visible = visible;
  }

  distance(target) {
    return Math.sqrt(Math.pow(target.getX() - this.getX(), 2) + Math.pow(target.getY() - this.getY(),2 ));
  }

  update(cw, ch) {
    if (this.gravity == false) {
    } else {

      let now = Date.now();
      let elapsed = now - this.then;
      if (elapsed > this.gravityDelay) {
        this.then = now;

        let closestDistance = Number.MAX_VALUE;
        let closestBody = null;
        let distances = {};
        let assets = getActiveAssets();
        var ctx = this;

        _.map(assets, function(body) {
          if (exists(body.mass)) {
            let distance = ctx.distance(body);
            distances[body] = distance;
            if (closestDistance > distance) {
              closestDistance = distance;
              closestBody = body;
            }
          }
        });

        // Keplers law. Or something.
        // This will allow all bodies of mass to affect
        // gravity-based things.
        _.map(assets, function(body) {
          if (!exists(body.mass)) {
            return;
          }

          let cx = body.x;
          let cy = body.y;
          let distance = distances[body];
          // 28000 is the "Josh constant" which provides good
          // gravity.
          //let intensity = 29000 / Math.pow(distance, 2);
          let intensity = 45000 / Math.pow(distance, 2);
          if (closestBody == body) {
            intensity = Math.max(intensity, 0.25);
          }

          let mag = Math.pow(cx - ctx.getX(), 2) + Math.pow(cy - ctx.getY(), 2);
          mag = Math.sqrt(mag);

          let unitVectorX = (cx - ctx.getX()) / mag;
          let unitVectorY = (cy - ctx.getY()) / mag;
          ctx.vx += unitVectorX * intensity;
          ctx.vy += unitVectorY * intensity;

          if (body.mainGravitySource) {
            // ctx.sr = -90 + (Math.atan2(unitVectorY, unitVectorX) * 180 / Math.PI);
          }
        });

        let thetaY = this.getY() - (ch/2);
        let thetaX = this.getX() - (cw/2);

        ctx.sr = -270 +  Math.atan2(thetaY, thetaX) * 180 / Math.PI;
      }
    }

    if ((exists(this.rax) || exists(this.ray)) && this.gravity) {
      this.rax += this.vx * this.gv;
      this.ray += this.vy * this.gv;
    } else {
      this.x += this.vx * this.gv;
      this.y += this.vy * this.gv;
    }

    _.map(this.assets, function(asset){ asset.update(cw, ch); });
  }

  getX() {
    if (exists(this.rax)) {
      return this.rax + this.ox;
    } else {
      return this.x + this.ox;
    }
  }

  getY() {
    if (exists(this.ray)) {
      return this.ray + this.oy;
    } else {
      return this.y + this.oy;
    }
  }

  render(ctx, cw, ch) {
    this.update(cw, ch);
    this.draw(ctx, cw, ch);
  }

  mouseDown() {

  }

  mouseMove() {

  }

  mouseUp() {

  }


  setRumbleRange(range) {
    this.rumbleRange = range;
  }

  startRumble() {
    this.rumbling = true;
  }

  stopRumble() {
    this.rumbling = false;
  }
}

module.exports = Drawable;
