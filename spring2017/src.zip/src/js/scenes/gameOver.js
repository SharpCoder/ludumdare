var Scene = require('../scene');
var Drawable = require('../drawable');

class GameOver extends Scene {

  constructor(obj) {
    super(obj);
    this.title = "GameOver";
  }

  draw(ctx, cw, ch) {

    if (this.visible) {
      ctx.fillStyle = "#FFF";
      ctx.font = "24px Neucha";
      ctx.fillText("Game Over (refresh page to reload)!", 150, 150);

      let text = "You lost";
      if (score < 80) {
        text = "Pathetic! Try harder!";
      } else if (score < 150) {
        text = "Nobody is impressed with this score.";
      } else if (score < 300) {
        text = "Unacceptable! You must play again!";
      } else if (score < 700) {
        text = "You have a pretty good score";
      } else {
        text = "GODLIKE!";
      }

      ctx.font = "60px Nuecha";
      ctx.fillText("Score: " + score, 150, 250);
      ctx.font = "24px Nuecha";
      ctx.fillText(text, 150, 350);
    }

  }

}

module.exports = GameOver;
