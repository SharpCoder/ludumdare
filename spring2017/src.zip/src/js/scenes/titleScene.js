var Scene = require('../scene');
var Drawable = require('../drawable');
var ForestPlanet = require('../objects/forestPlanet');

class TitleScene extends Scene {

  constructor(obj) {
    super(_.defaults({}, obj, {
      title: "TitleScene"
    }));

    this.then = Date.now();
    this.addAsset(new ForestPlanet({
      image: "planet1",
      mainGravitySource: true
    }));
  }

  draw(ctx, cw, ch) {
    super.draw(ctx, cw, ch);

    ctx.font = "24px Neucha";
    ctx.fillStyle = "#FFF";

    let text = "Click anywhere to begin!";
    let size = ctx.measureText(text);
    ctx.fillText("Click anywhere to begin!", (cw - size.width)/2, ch-50);
    ctx.fill();
  }

  mouseDown() {
    setScene("MainScene");
  }
}

module.exports = TitleScene;
