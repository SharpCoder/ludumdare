var Scene = require('../scene');
var Drawable = require('../drawable');
var Character = require('../objects/character');
var ForestPlanet = require('../objects/forestPlanet');
var Hud = require('../objects/hud');
var Explosion = require('../objects/explosion');
var Arrow = require('../objects/arrow');
var Nice = require('../objects/nice');

class MainScene extends Scene {

  constructor(obj) {
    super(_.defaults({}, obj, {
      title: "MainScene"
    }));

    this.explosion_sound = Assets.get("explosion");
    this.rocket_sound = Assets.get("rocket_start");
    this.then = Date.now();
    this.generateWorld(1);
  }

  onStart() {
    let music = Assets.get("bg_loop");
    music.loop = true;
    music.play();
  }

  generateWorld(level, planet) {
    level = level || 1;
    window.level = level;
    window.fuel = 100 * level;


    this.zoomTo(0.9);
    this.rocket_sound.load();
    this.rocket_sound.pause();
    this.explosion_sound.load();
    this.explosion_sound.pause();

    delete this.player;
    delete this.world;
    delete this.assets;
    this.assets = [];
    let world = new Drawable();

    let targetPlanetSize = 150 + Math.round(Math.random() * (150 * level));
    let tpX = 800 + (150 * Math.random() * level);
    let tpY = 800 + (150 * Math.random() * level);
    
    if (Math.random() > 0.5) tpX *= -1;
    if (Math.random() > 0.5) tpY *= -1;


    let targetPlanet = new ForestPlanet({
      image: "planet0",
      x: tpX,
      y: tpY,
      width: Math.min(targetPlanetSize, 600),
      height: Math.min(targetPlanetSize, 600)
    });

    if (!planet) {
      planet = new ForestPlanet({
        image: "planet1",
        mainGravitySource: true
      });
    } else {
      planet.mainGravitySource = true;
    }

    this.success = false;
    let character = new Character();
    this.player = character;
    this.addAsset(character);

    this.hud = new Hud();
    planet.setPlayer(character);

    world.addAsset(planet);
    world.addAsset(targetPlanet);
    this.addAsset(this.player);

    this.planet = planet;
    this.targetPlanet = targetPlanet;
    this.world = world;
    this.addAsset(world);

    // Create the arrow
    this.arrow = new Arrow();
    this.world.addAsset(this.arrow);
    return world;
  }

  draw(ctx, cw, ch) {

    // Code below for camera frame
    this.hud.draw(ctx, cw, ch);
    ctx.save();
    let diffX = this.player.getX() - cw/2;
    let diffY = this.player.getY() - ch/2;
    ctx.translate(-diffX/2, -diffY/2);
    super.draw(ctx, cw, ch);
    ctx.restore();
    // END CAMERA FRAME

  }

  update(cw, ch) {
    super.update(cw, ch);
    if (this.success == true) {
      this.player.vx = 0;
      this.player.vy = 0;
      this.player.setVisible(false);
      return;
    }

    this.arrow.ox = cw/2;
    this.arrow.oy = ch/2;
    this.arrow.rotation = Math.atan2(this.targetPlanet.y-this.arrow.oy , this.targetPlanet.x-this.arrow.ox) * 180 / Math.PI;

    if (fuel == 0) {
      this.gameOver = true;
      setScene("GameOver");
    }

    if (this.mouse) {
      let power = this.calculatePower()
      this.hud.setPower(power);
      this.player.setRumbleRange(power);
    }

    if (this.player.gravity) {

      let now = Date.now();
      let elapsed = now - this.then;
      if (elapsed >= 250) {
        fuel = Math.max(fuel - 1, 0);
        score += 1;
        this.then = now;
      }

      let success = this.player.distance(this.targetPlanet) < (this.targetPlanet.width/2);
      if (success && this.success == false) {
        this.success = true;
        var vtx = this;
        score += 10 * level;
        this.player.vy = 0;
        this.player.vx = 0;

        Assets.get("success").play();
        this.world.addAsset(new Nice({
          text: "Nice!",
          x: this.player.getX(),
          y: this.player.getY(),
          success: function() {
            vtx.generateWorld(level + 1, vtx.targetPlanet);
          }
        }));
      }

      this.player.gtime = (this.player.gtime || 0) + 1;
      let planetX = cw/2;//this.planet.x;
      let planetY = ch/2;//this.planet.y;
      let playerX = this.player.rax;
      let playerY = this.player.ray;

      let distance = Math.pow(planetX - playerX, 2) + Math.pow(planetY - playerY, 2);
      distance = Math.sqrt(distance) * this.scale;

      if (this.player.gtime > 50 && distance < 80 && this.gameOver != true) {
        this.gameOver = true;
        this.player.setVisible(false);

        this.explosion_sound.load();
        this.explosion_sound.play();

        // Arbitrary positioning ftw
        this.addAsset(new Explosion({
          rotation: this.player.sr,
          x: this.player.getX() + this.player.ox + 50,
          y: this.player.getY() + 50 + this.player.height / 2,
          complete: function() {
            setScene("GameOver");
          }
        }));
      }
    }
  }

  calculatePower() {
    let power = new Date().getTime() - this.powerStart;
    return Math.round(power / 5);
  }

  mouseMove() {

  }

  mouseDown() {
    this.mouse = true;
    this.powerStart = new Date().getTime();

    // If the player has not launched yet, then
    // allow rumble.
    if (this.player.gravity == false) {
      this.player.startRumble();
      this.rocket_sound.loop = true;
      this.rocket_sound.load();
      this.rocket_sound.play();
    }
  }

  mouseUp() {
    this.mouse = false;
    let power = this.calculatePower();
    this.player.stopRumble();
    this.rocket_sound.pause();
    this.explosion_sound.play();
    this.zoomTo(0.40, 0.08);

    if (this.player.gravity == false) {
      this.planet.stopRotatingPlayer();
      this.player.gv = 0.25;

      let c = power / 10;
      let rotation = this.player.rotation - 90;
      this.player.vx = c * Math.cos(rotation / 180 * Math.PI);
      this.player.vy = c * Math.sin(rotation / 180 * Math.PI);
      this.player.gravity = true;
    }
  }

}

module.exports = MainScene;
