window.$ = require('jquery');
window._ = require('underscore');

var Assets = require('./assets');
var Engine = require('./engine');

var TitleScene = require('./scenes/titleScene');
var MainScene = require('./scenes/mainScene');
var GameOver = require('./scenes/gameOver');

$(document).ready(function() {
  window.Assets = new Assets(function() {
    let engine = new Engine("canvas");
    engine.addScene(new TitleScene());
    engine.addScene(new MainScene());
    engine.addScene(new GameOver());

    // Events
    $(document).on("mousemove", function(evt) {
      engine.mouseMove(evt.offsetX, evt.offsetY);
    });

    var md = _.debounce(function() {
      engine.mouseDown();
    }, 250);
    
    $(document).on("mousedown", function() {
      md();
    });

    $(document).on("mouseup", function() {
      engine.mouseUp();
    });

  });
})
