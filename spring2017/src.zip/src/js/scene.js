var Drawable = require("./drawable");

class Scene extends Drawable {

  constructor(obj) {
    super(obj);
    this.scale = 1.0;
    this.scaleDelta = 0.05;
    this.targetScale = 1.0;
    this.rumbling = false;
  }

  onStart() {
    
  }

  setScale(scale) {
    this.scale = scale;
    this.targetScale = scale;
  }

  draw(ctx, cw, ch) {
    ctx.save();
    ctx.translate(cw / 2,ch/2);
    ctx.scale(this.scale, this.scale);
    ctx.translate(-cw/2, -ch/2);
    super.draw(ctx, cw, ch);
    ctx.restore();

  }

  update(cw, ch) {
    super.update(cw, ch);
    if (this.scale != this.targetScale) {
      if (Math.abs(this.scale - this.targetScale) <= (this.scaleDelta * 2)) {
        this.scale = this.targetScale;
      }

      if (this.scale > this.targetScale) {
        this.scale -= this.scaleDelta;
      } else {
        this.scale += this.scaleDelta;
      }
    }
  }

  zoomTo(scale, delta) {
    this.targetScale = scale;
    this.scaleDelta = delta || this.scaleDelta;
  }

}

module.exports = Scene;
