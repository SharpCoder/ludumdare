class Assets {

  constructor(klasscb) {
    var ctx = this;
    this.loaded = {};
    this.sounds = [
      "bg_loop.mp3",
      "rocket_start.mp3",
      "explosion.mp3",
      "success.mp3"
    ];
    this.images = [
      "explosion_1.png",
      "explosion_2.png",
      "explosion_3.png",
      "explosion_4.png",
      "explosion_5.png",
      "planet1.png",
      "planet4.png",
      "space_bg6.jpg",
      "planet0.png",
      "planet2.png",
      "tree.png",
      "arrow.png",
      "rocket.png"
    ];

    function processSounds(index, callback) {
      if (index >= this.sounds.length) {
        callback();
        return;
      }

      let name = removeExt(this.sounds[index]);
      this.loaded[name] = new Audio('./assets/' + this.sounds[index]);
      processSounds.call(ctx, index + 1, callback);
    }

    function removeExt(src) {
      if (src.indexOf('.') >= 0) {
        return src.substr(0, src.indexOf('.'));
      } else {
        return src;
      }
    }

    function processImage(index, callback) {
      if (index >= this.images.length) {
        processSounds.call(ctx, 0, callback);
        return;
      }

      let name = removeExt(this.images[index]);
      let src = "./assets/" + this.images[index];

      this.loaded[name] = new Image();
      this.loaded[name].onload = function() {
        processImage.call(ctx, index + 1, callback);
      }
      this.loaded[name].src = src;
    }

    processImage.call(ctx, 0, klasscb);
  }

  get(assetName) {
    return this.loaded[assetName];
  }

}

module.exports = Assets;
