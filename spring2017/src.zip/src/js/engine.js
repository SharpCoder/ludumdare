class Engine {

  constructor(canvasId) {
    window.mouseX = 0;
    window.mouseY = 0;
    window.exists = function(obj) {
      return obj !== undefined && obj !== null;
    }
    window.getActiveAssets = this.getActiveAssets.bind(this);
    window.setScene = this.setScene.bind(this);
    window.score = 0;
    window.fuel = 100;

    let canvas = document.getElementById(canvasId);
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');

    canvas.width = $(".canvas-container").width();
    canvas.height = $(".canvas-container").height();

    this.sceneNames = [];
    this.scenes = [];
    this.activeScene = -1;

    // Configure the target frames-per-second.
    let targetFPS = 40;

    this.fpsInterval = 1000 / targetFPS;
    this.then = Date.now();
    this.startTime = this.then;
    this.render();
  }

  render() {
    // Do forever.
    requestAnimationFrame(this.render.bind(this));

    let now = Date.now();
    let elapsed = now - this.then;

    if (elapsed > this.fpsInterval) {
      this.then = now - (elapsed % this.fpsInterval);
      this.cw = this.canvas.width;
      this.ch = this.canvas.height;

      // Clear the drawable area.
      this.ctx.clearRect(0, 0, this.cw, this.ch);

      // Render the main screen.
      if (exists(this.scenes[this.activeScene])) {
        this.scenes[this.activeScene].render(this.ctx, this.cw, this.ch);
      }
    }
  }

  getActiveAssets() {
    if (this.activeScene >= 0) {
      return this.scenes[this.activeScene].getAssets();
    }
  }

  addScene(scene) {
    this.sceneNames.push(scene.title);
    this.scenes.push(scene);
    if (this.activeScene == -1) {
      this.activeScene = this.scenes.length - 1;
    }
  }

  setScene(title) {
    this.activeScene = this.sceneNames.indexOf(title);
  }

  mouseMove(x, y) {
    window.mouseX = x;
    window.mouseY = y;
    if (this.activeScene >= 0) {
      this.scenes[this.activeScene].mouseMove();
    }
  }

  mouseDown() {
    if (this.activeScene >= 0) {
      this.scenes[this.activeScene].mouseDown();
    }
  }

  mouseUp() {
    if (this.activeScene >= 0) {
      this.scenes[this.activeScene].mouseUp();
    }
  }

}

module.exports = Engine;
